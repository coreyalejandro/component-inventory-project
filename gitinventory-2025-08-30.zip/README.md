
# GitInventory (Node.js/TypeScript)

A production-grade service that inventories GitHub repositories and exposes signed JSON reports via REST.

## One-screen Quick Start (Local, Docker Compose)

1. Open a terminal in this folder.
2. Copy `.env.example` to `.env` and fill `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET` from your GitHub OAuth App.
3. Run:
   ```bash
   docker compose up --build
   ```
4. Wait until you see: `server listening on 0.0.0.0:3000`.
5. In your browser go to: `http://localhost:3000/docs` (OpenAPI) and `http://localhost:3000/healthz`.

## Minimal Flow

- POST `/v1/repos/scan` with service JWT to enqueue a scan:
  ```bash
  curl -sS -X POST     -H "Authorization: Bearer dev-dev-dev"     -H "Content-Type: application/json"     -d '{"owner":"octocat","repo":"Hello-World"}'     http://localhost:3000/v1/repos/scan
  ```
- GET `/v1/repos/{owner}/{repo}/inventory` to fetch inventory.

## OAuth Login (User Flow)

- Visit `http://localhost:3000/oauth/github/login` to authenticate.
- The server stores a hashed token reference and rotates JWTs. In production, store tokens in a KMS-backed secret store.

## Testing

```bash
npm ci
npm run build
npm test
```

## Notes

- This build implements full inventory for Node (npm/yarn/pnpm), direct deps for several ecosystems, and OSV vulnerability lookups.
- Large files and LOC calculations are guarded by safety thresholds to respect GitHub rate limits.
