
# GitInventory Dashboard (Next.js, App Router)

A production-ready dashboard that works with the GitInventory backend.

## One-screen Run

1. In the backend project, run the API at `http://localhost:3000` (Docker Compose or `npm start`).  
2. In this folder, create `.env.local`:
   ```env
   NEXT_PUBLIC_BACKEND_URL=http://localhost:3000
   ```
3. Install and start:
   ```bash
   npm install
   npm run dev
   ```
4. In your browser, open `http://localhost:3001`.

## First scan (no CORS, no hacks)

- Click **Login with GitHub** link (opens backend at `/oauth/github/login`), complete login, copy the JWT it shows.
- Paste the JWT into the **Paste JWT** field.
- Enter `owner`, `repo`, and optional `gitRef`.
- Click **Scan now**.
- The tile for `octocat/Hello-World` will update when a scan exists. Click **Open details** for the repo page.

## Notes

- The frontend proxies requests server-side, so the browser makes no cross-origin calls.
- UI uses Tailwind with ShadCN-like components (no external CLI needed).
- Charts use `recharts`.
